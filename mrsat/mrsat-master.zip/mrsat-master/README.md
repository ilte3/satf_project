# mrsat
A set of R functions useful for analysis of data from  multi-response speed accuracy trade-off (mrSAT) studies.

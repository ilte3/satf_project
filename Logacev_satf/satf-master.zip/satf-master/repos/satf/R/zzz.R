
.onLoad <- function (lib, pkg)   {
	library.dynam("satf", pkg, lib)
}

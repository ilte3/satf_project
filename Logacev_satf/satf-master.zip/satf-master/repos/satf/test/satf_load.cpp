#include "../src/rcpp_exports.cpp"
#include "../src/satf.cpp"
#include "../src/satf_math.cpp"
#include "../src/debug.cpp"
#include "../src/datapoint.cpp"
#include "../src/design_matrix_new.cpp"
#include "../src/coefs.cpp"
#include "../src/data.cpp"

